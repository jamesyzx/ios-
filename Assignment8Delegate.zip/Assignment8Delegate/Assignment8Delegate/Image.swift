//
//  Image.swift
//  Assignment8Delegate
//
//  Created by James on 2018/11/7.
//  Copyright © 2018年 James. All rights reserved.
//

import Foundation
import UIKit
class  Image{
    var image :UIImage
    var title : String
    var model : String
    var year : String
    init(image:UIImage,title :String,year:String ,model :String) {
        self.image = image
        self.title = title
        self.model = model
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = "YYYY"
      //  self.year=dateformatter.date(from: year)!
        self.year = year
    }
}
