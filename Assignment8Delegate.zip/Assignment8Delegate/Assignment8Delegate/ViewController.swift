//
//  ViewController.swift
//  Assignment8Delegate
//
//  Created by James on 2018/11/6.
//  Copyright © 2018年 James. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
       
       
    
    }



}

