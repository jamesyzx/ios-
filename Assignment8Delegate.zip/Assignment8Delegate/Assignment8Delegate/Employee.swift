//
//  Employee.swift
//  Assignment8Delegate
//
//  Created by James on 2018/11/6.
//  Copyright © 2018年 James. All rights reserved.
//

import Foundation
class Employee{
    var address : String?
    var city : String?
    var firstname : String?
    var lastname : String?
    var phone : String?
    var ssn : String?
    var zip : String?
    
}
