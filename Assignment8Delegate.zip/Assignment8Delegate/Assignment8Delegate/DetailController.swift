//
//  DetailController.swift
//  Assignment8Delegate
//
//  Created by James on 2018/11/7.
//  Copyright © 2018年 James. All rights reserved.
//

import UIKit

class DetailController: UIViewController, UITextFieldDelegate,UITextViewDelegate {

    var image = UIImage()
    var labelMark = ""
    var labelModel = ""
    var labelYear = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = "Detail of the vehicle"

        
    
       
        let label1 = UILabel(frame: CGRect(x: 20, y: 100, width: 380, height: 100))
        label1.backgroundColor = UIColor.orange
        label1.textAlignment = .center
        label1.adjustsFontSizeToFitWidth = true
        label1.font = UIFont.boldSystemFont(ofSize: 24)
        label1.textColor = UIColor.black
        label1.text = labelMark
        view.addSubview(label1)
        
        let imageshow = UIImageView(frame: CGRect(x: 0, y: 250, width: 400, height: 300))
        imageshow.image = image
        view.addSubview(imageshow)
        

        let label2 = UILabel(frame: CGRect(x: 20, y: 580, width: 380, height: 100))
        label2.backgroundColor = UIColor.orange
        label2.textAlignment = .center
        label2.adjustsFontSizeToFitWidth = true
        label2.font = UIFont.boldSystemFont(ofSize: 24)
        label2.textColor = UIColor.black
        label2.text = labelModel
        view.addSubview(label2)
        
        let label3 = UILabel(frame: CGRect(x: 20, y: 680, width: 380, height: 100))
        label3.backgroundColor = UIColor.orange
        label3.textAlignment = .center
        label3.adjustsFontSizeToFitWidth = true
        label3.font = UIFont.boldSystemFont(ofSize: 24)
        label3.textColor = UIColor.black
        label3.text = labelYear
        view.addSubview(label3)
    }
    


}
