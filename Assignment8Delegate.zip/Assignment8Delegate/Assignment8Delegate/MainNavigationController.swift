//
//  MainNavigationController.swift
//  Assignment8Delegate
//
//  Created by James on 2018/11/6.
//  Copyright © 2018年 James. All rights reserved.
//

import UIKit
class MainNavigationContoller: UINavigationController {
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        let homeController = HomeContoller()
        viewControllers = [homeController]
        
        
    }
    
}

class HomeContoller: UIViewController {
    
    var images :[Image] = []
    var tableView:UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.title = "Welcome"
        view.backgroundColor = UIColor.gray
       
        let addButton = UIBarButtonItem(barButtonSystemItem:.add,
                                        target: self,
                                        action: #selector(addcar(sender:)))
        
        navigationItem.rightBarButtonItem = addButton
       
        //edit

        let deleteButton = UIBarButtonItem(barButtonSystemItem:.edit,
                                           target: self,
                                           action: #selector(editAction))
        
        navigationItem.leftBarButtonItem = deleteButton

        
        self.tableView = UITableView(frame:  CGRect(x:0,y:0,width:420, height:800), style: .plain)

        self.tableView.backgroundColor = UIColor.white
       
        images = createArray()
         self.tableView.delegate = self
       self.tableView.dataSource = self
        self.tableView.isScrollEnabled = true
        view.addSubview(tableView)
        self.tableView.register(ImageCell.self, forCellReuseIdentifier: "cellID")

    }
    
    @objc func removeSubview(){
        print("Start remove sibview")
        if let viewWithTag = self.view.viewWithTag(100) {
            viewWithTag.removeFromSuperview()
        }else{
            print("No!")
        }
    }

    
    @objc func editAction(){
        tableView.setEditing(true, animated: true)
       
        let backButton = UIBarButtonItem(barButtonSystemItem:.done,
                                         target: self,
                                         action: #selector(back))
        
        navigationItem.leftBarButtonItem = backButton
    }
    @objc func back(){
       tableView.setEditing(false, animated: true)
        let addButton = UIBarButtonItem(barButtonSystemItem:.edit,
                                        target: self,
                                        action: #selector(editAction))
        
        navigationItem.leftBarButtonItem = addButton
    }
    @objc func addcar(sender: AnyObject) {
        let alert = UIAlertController(title: "Add Car", message: nil, preferredStyle: .alert)
        alert.addTextField{(desstf) in desstf.placeholder = "Enter Car Picture"
        }
        alert.addTextField{(mark) in mark.placeholder = "Enter Car Mark"
        }
        alert.addTextField{(model) in model.placeholder = "Enter Car Model"
        }
        alert.addTextField{(year) in year.placeholder = "Enter Car Year"
        }
       
        alert.addAction(UIAlertAction(title: "Add", style: .default){
            (_)in
            guard let car = alert.textFields?.first?.text
                else{return}
            if !car.isAlpha(ignoreDiacritics: true)
            { return }
            guard let m = alert.textFields![1].text
                else{return}
            if !m.isAlpha(ignoreDiacritics: true)
            { return }
            guard let mo = alert.textFields![2].text
                else{return}
            if !mo.isAlpha(ignoreDiacritics: true)
            { return }
            guard let y = alert.textFields![3].text
                else{return}
            if !self.checkDate(s: y)
            {return}
            let newImage = UIImage(named: car)
            let imageView = UIImageView(image:newImage)
            let image1 = Image(image: newImage!, title: m, year:y,model:mo)
            self.images.append(image1)
            self.tableView.reloadData()
        })
        alert.show()
      
        
    }
    func checkDate(s:String)-> Bool{
        
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = "YYYY-MM-dd"
        if  let newDate = dateformatter.date(from: s)
        {
            return true
        }
        else{
            return false
        }
        
    }
    
   
    
    @objc func edit(sender: AnyObject) {
       print("edit")
    }
    
    func createArray()->[Image]{
        var temImages :[Image] = []
        let newImage = UIImage(named: "1")
        let imageView = UIImageView(image:newImage)
        let image1 = Image(image: newImage!, title: "BMW",year:"1998",model:"M3")
        temImages.append(image1)
        let newImage1 = UIImage(named: "2")
        let imageView1 = UIImageView(image:newImage1)
        let image11 = Image(image: newImage1!, title: "BENZ",year:"1999",model:"SLS")
        temImages.append(image11)
        return temImages
    }
   
    
}


public extension UIAlertController {
    func show() {
        let win = UIWindow(frame: UIScreen.main.bounds)
        let vc = UIViewController()
        vc.view.backgroundColor = .clear
        win.rootViewController = vc
        win.windowLevel = UIWindow.Level.alert + 1
        win.makeKeyAndVisible()
        vc.present(self, animated: true, completion: nil)
    }
}
extension String{
    func isAlpha(ignoreDiacritics: Bool = false) -> Bool {
        if ignoreDiacritics {
            return self.range(of: "[^a-zA-Z]", options: .regularExpression) == nil && self != ""
        }
        else {
            return self.isAlpha()
        }
    }
    func isAlphaNum(ignoreDiacritics: Bool = false) -> Bool {
        if ignoreDiacritics {
            return self.range(of: "[^a-zA-Z0-9]", options: .regularExpression) == nil && self != ""
        }
        else {
            return self.isAlpha()
        }
    }
}
extension HomeContoller:UITableViewDataSource,UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return images.count
    }
    
    //设置section的数量
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    //设置tableview的cell
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let image = images[indexPath.row]
        
        let  cell = tableView.dequeueReusableCell(withIdentifier: "cellID") as! ImageCell
        
        print("dwqdwq\(image.image)")
        cell.setImage(image: image)
        
        return cell
     
        
    }
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        print("duwqgdwiqugdoqwugd")
        return true
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        guard editingStyle == .delete else {
            return
        }
        images.remove(at: indexPath.row)
        tableView.deleteRows(at: [indexPath], with: .right)
       
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let dc = DetailController()
        dc.labelMark = images[indexPath.row].title
        dc.image = images[indexPath.row].image
        dc.labelModel  = images[indexPath.row].model
        dc.labelYear  = images[indexPath.row].year
        self.navigationController?.pushViewController(dc, animated: true)
    }
    
    private func tableView(tableView: UITableView, willSelectRowAtIndexPath indexPath: NSIndexPath) -> NSIndexPath? {
        
        // 这个方法第一次调用的时候 indexPath 为 nil
        if  let selectedRowIndexPath = tableView.indexPathForSelectedRow {
            // 去除上一次选中
            tableView.deselectRow(at: selectedRowIndexPath, animated: true)
        }
        return indexPath
    }
    
    func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: IndexPath) -> Bool {
        
        
        return true
    }
    
   
  
    
}
