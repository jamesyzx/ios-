//
//  Vehicle.swift
//  Assignment8Delegate
//
//  Created by James on 2018/11/7.
//  Copyright © 2018年 James. All rights reserved.
//

import Foundation
class Vehicle{
    var make : String
    var miles : Double
    var model : String
    var photo : String
    var price : Double
    var rating : Int
    var type : String
    var year : Date
    init(make:String,miles:Double,model:String,photo:String,price:Double,rating:Int,type:String,year:String) {
        self.make=make
        self.miles=miles
        self.model=model
        self.photo=photo
        self.price=price
        self.rating=rating
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = "YYYY-MM-dd"
        self.year=dateformatter.date(from: year)!
        self.type=type
    }
    
}
