//
//  Dealer.swift
//  Assignment8Delegate
//
//  Created by James on 2018/11/6.
//  Copyright © 2018年 James. All rights reserved.
//

import Foundation

class Dealer{
    var address : String?
    var city : String?
    var name : String?
    var phone : String?
    var zip : String?
    var departmentlist : [Department]?
    
}
