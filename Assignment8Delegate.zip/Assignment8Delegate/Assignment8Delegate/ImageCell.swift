//
//  ImageCell.swift
//  Assignment8Delegate
//
//  Created by James on 2018/11/7.
//  Copyright © 2018年 James. All rights reserved.
//

import UIKit

class ImageCell: UITableViewCell{
    var imageViewp = UIImageView()
    var imageTitle = UILabel()
    
    var box = UIView()
    
    
    
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style:style,reuseIdentifier:reuseIdentifier)
        
        imageTitle = UILabel(frame: CGRect(x: 200, y: 20, width: 100, height: 30))
    
        imageTitle.backgroundColor = UIColor.orange
        imageTitle.textAlignment = .center
        imageTitle.clipsToBounds = true
        imageTitle.adjustsFontSizeToFitWidth = true
        imageTitle.font = UIFont.boldSystemFont(ofSize: 30)
        imageTitle.textColor = UIColor.black
        
        imageViewp = UIImageView(frame: CGRect(x: 20, y: 0, width: 120, height: 120))
        imageViewp.clipsToBounds = true
        
        
        box.addSubview(imageViewp)
        box.addSubview(imageTitle)
        self.addSubview(box)
        
    }
    func setImage(image :Image)->Void{
        
        imageViewp.image = image.image
        print(imageTitle.text)
        imageTitle.text = image.title
        print(imageTitle.text)
        print("2")
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        self.selectionStyle = UITableViewCell.SelectionStyle.gray
        
        // Configure the view for the selected state
    }
    
}



