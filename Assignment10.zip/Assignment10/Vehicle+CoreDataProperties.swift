//
//  Vehicle+CoreDataProperties.swift
//  Assignment9
//
//  Created by James on 2018/11/25.
//  Copyright © 2018年 James. All rights reserved.
//
//

import Foundation
import CoreData


extension Vehicle {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Vehicle> {
        return NSFetchRequest<Vehicle>(entityName: "Vehicle")
    }

    @NSManaged public var image: String?
    @NSManaged public var mark: String?
    @NSManaged public var model: String?
    @NSManaged public var year: String?
    @NSManaged public var id: Int32
}
