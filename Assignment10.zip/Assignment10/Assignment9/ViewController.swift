//
//  ViewController.swift
//  Assignment9
//
//  Created by James on 2018/11/13.
//  Copyright © 2018年 James. All rights reserved.
//

import UIKit
import CoreData


class ViewController: UIViewController, UISearchBarDelegate,UISearchControllerDelegate {

  
    
    @IBOutlet weak var addBtn: UIBarButtonItem!
    @IBOutlet weak var tableView: UITableView!
     var vehicles: [NSManagedObject] = []
     var count = 0
    let searchController = UISearchController(searchResultsController: nil)
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        DataModelSetup()
       
       searchBarSetup()
      
         self.tableView.reloadData()
    }
    
    func DataModelSetup(){
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {return }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Vehicle")
        
        do {
            vehicles = try managedContext.fetch(fetchRequest)
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
    }
    func searchBarSetup(){
        searchController.searchResultsUpdater = self as! UISearchResultsUpdating
        searchController.searchBar.delegate = self
     
          searchController.obscuresBackgroundDuringPresentation = false
         searchController.searchBar.placeholder = "Search by Mark"
        searchController.hidesNavigationBarDuringPresentation = false
        definesPresentationContext = true
      //下拉显示
     //   navigationItem.searchController = searchController
    //直接显示
        navigationItem.titleView = searchController.searchBar
        
      
    }
    
   
    //cooredata function
    
    func getContext () -> NSManagedObjectContext {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        return appDelegate.persistentContainer.viewContext
    }
    
   
        
    func save() {
            guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
            appDelegate.saveContext()
        print("save finished")
        }
        
    func update() {
            guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
            let managedContext = getContext()
            let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Vehicle")
            do{
                let result = try managedContext.fetch(fetchRequest)
                let objectUpdate = result[0] as! NSManagedObject
               
            }
            catch{
                print("update error")
            }
            
        }
    
    //
  
    func createVehicle(imgae:String, mark:String,model:String,year :String){
        let context = getContext()
        let vehicle1 = NSEntityDescription.insertNewObject(forEntityName: "Vehicle", into: context) as! Vehicle
        vehicle1.image=imgae
        vehicle1.id = Int32(count)
        vehicle1.mark=mark
        vehicle1.model=model
        vehicle1.year=year
        count+=1
        vehicles.append(vehicle1)
        print("vehicle has been created")
     
    }
    
    
    //id don't konw
    func getVehicles(){
          let context = getContext()
        //
         guard let vehicles = try! context.fetch(Vehicle.fetchRequest()) as? [Vehicle] else { return}
        
        for v in vehicles {
            if let id = v.value(forKeyPath: "id") as? Int{
                if id > count{
                    count = id
                }
            }
            else{print("no id")}
        }
    
    }
    
    
    func getVehicle(id: String) -> NSManagedObject?{
        let context = getContext()
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>.init(entityName: "Vehicle")
        fetchRequest.predicate = NSPredicate(format: "id = %@", id)
        do{
            let vs = try context.fetch(fetchRequest)
            let v = vs[0] as! NSManagedObject
            return v
        }
        catch {
            print("fetch error")
        }
        return nil
    }
    
    
    
    func resetAllRecords(in entity : String) // entity = Your_Entity_Name
    {
        
        let context = ( UIApplication.shared.delegate as! AppDelegate ).persistentContainer.viewContext
        let deleteFetch = NSFetchRequest<NSFetchRequestResult>(entityName: entity)
        let deleteRequest = NSBatchDeleteRequest(fetchRequest: deleteFetch)
        do
        {
            try context.execute(deleteRequest)
            try context.save()
        }
        catch
        {
            print ("There was an error")
        }
    }
    
    
    //original
    
    @IBAction func addaction(_ sender: Any) {


        var avc = storyboard?.instantiateViewController(withIdentifier: "addViewController") as? addViewController
       
        
        self.navigationController?.pushViewController(avc!, animated: true)
        
    }
    
    

    @IBAction func editaction(_ sender: UIBarButtonItem) {
         self.tableView.isEditing = !self.tableView.isEditing
        sender.title = (self.tableView.isEditing) ?"Done":"Edit"
    }
    
}
extension ViewController:UITableViewDataSource,UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return vehicles.count
    }
    
    //设置section的数量
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    //设置tableview的cell
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let  cell = tableView.dequeueReusableCell(withIdentifier: "ImageCell") as! ImageCell
        
        let vehicle = vehicles[indexPath.row]
        
        cell.carImageView.image = readImg(vehicle.value(forKey: "image") as? String ?? "")
        cell.carTtileLabel.text = "Mark: \((vehicle.value(forKeyPath: "mark") as? String)!)"
    
        
        return cell
        
        
    }
   
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        guard editingStyle == .delete else {
            return
        }
     
        let vehicle = vehicles[indexPath.row]
        guard let deleteObject = getVehicle(id: String((vehicle.value(forKey: "id") as? Int)!)) else{ print("deleteObject not found");return}
        getContext().delete(deleteObject)
        
        vehicles.remove(at: indexPath.row)
        self.tableView.deleteRows(at: [indexPath], with: .fade)
        save()
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    var dc = storyboard?.instantiateViewController(withIdentifier: "DetailController") as? DetailController
       let vehicle = vehicles[indexPath.row]
        dc?.mark = (vehicle.value(forKey: "mark")as? String)!
        dc?.img = (vehicle.value(forKey: "image")as? String)!
        dc?.model  = (vehicle.value(forKey: "model")as? String)!
        dc?.year = (vehicle.value(forKey: "year")as? String)!
       dc?.id = (vehicle.value(forKey: "id")as? Int32)!
        dc?.changevhicle = vehicle
        
        self.navigationController?.pushViewController(dc!, animated: true)
    }
    
    
    func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        
       let carTemp = vehicles[sourceIndexPath.row]
        vehicles.remove(at: sourceIndexPath.row)
        vehicles.insert(carTemp, at: sourceIndexPath.row)
        
        
    }
    
    

}

extension ViewController: UISearchResultsUpdating{
    func updateSearchResults(for searchController: UISearchController) {
        //later
        var temp = [Vehicle]()
        guard let searchText = searchController.searchBar.text else {return}
        if searchText == ""{
            DataModelSetup()
        }else{
            
            let temp = vehicles.filter { (s) -> Bool in
                guard s.value(forKey: "mark")as?String == searchText else{
                    return false
                }
                return true
            }
            vehicles.removeAll()
            vehicles = temp
            
            }
        
             tableView.reloadData()
        }
    
    
}
public extension UIViewController {
    func saveImg(_ fileName: String, _ pickedImageProduct: UIImage){
        let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
       
        let fileURL = documentsDirectory.appendingPathComponent(fileName)
        // get your UIImage jpeg data representation and check if the destination file url already exists
        if let data = pickedImageProduct.jpegData(compressionQuality: 1.0),
            !FileManager.default.fileExists(atPath: fileURL.path) {
            do {
                // writes the image data to disk
                try data.write(to: fileURL)
                print("file saved")
            } catch {
                print("error saving file:", error)
            }
        }
    }
    
    func readImg(_ fileName: String)-> UIImage?{
        let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let fileURL = documentsDirectory.appendingPathComponent(fileName)
        if FileManager.default.fileExists(atPath: fileURL.path){
            //            img.image = UIImage(contentsOfFile: fileURL.path)
            return UIImage(contentsOfFile: fileURL.path)!
        }else{
            print("No Image")
        }
        return nil
    }
    
    
}


