//
//  DetailController.swift
//  Assignment9
//
//  Created by James on 2018/11/13.
//  Copyright © 2018年 James. All rights reserved.
//

import UIKit
import  CoreData

class DetailController: UIViewController,UINavigationControllerDelegate ,UIImagePickerControllerDelegate {

    private var datePicker:UIDatePicker?
     var vehicles: [NSManagedObject] = []
    @IBOutlet weak var markLabel: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var modelLabel: UILabel!
    @IBOutlet weak var yearLabel: UILabel!
    
    @IBOutlet weak var markTxt: UITextField!
    
    @IBOutlet weak var modelTtx: UITextField!
    
    @IBOutlet weak var imageNameTxt: UITextField!
    
    @IBOutlet weak var inuptTxt: UITextField!
    
     var changevhicle =  NSManagedObject()
    var img = ""
    var mark = ""
    var model = ""
    var year = ""
    var id : Int32 = 0
    
    
  
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       configureView()
        datePickerSetup()

        // Do any additional setup after loading the view.
    }
    func configureView(){
        markTxt.text = mark
        modelTtx.text = model
        inuptTxt.text = year
        imageNameTxt.text = img
        imageView.image = readImg(img)
        
    }
    

    @IBAction func editBtn(_ sender: Any) {
        self.markTxt.isEnabled = true
        self.imageNameTxt.isEnabled = true
        self.modelTtx.isEnabled = true
        self.inuptTxt.isEnabled = true
    }
    
    @IBAction func updateBtn(_ sender: Any) {
        var editmark = ""
        var editmodel = ""
        var editdate = ""
        var editimagename = ""
        editmark = markTxt.text!
        editmodel = modelTtx.text!
        editdate = inuptTxt.text!
        editimagename = imageNameTxt.text!
        let alert = UIAlertController(title: "Alert", message: "Please check your typing", preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        if !editmark.isAlpha(ignoreDiacritics: true) { alert.show(); print("mark") ;return}
       // if !editmodel.isAlpha(ignoreDiacritics: true) { alert.show(); print("model");return}
        //if !editdate .isAlpha(ignoreDiacritics: true) { alert.show(); print("date");return}
        if !editimagename .isAlpha(ignoreDiacritics: true) { alert.show(); print("name");return}
        
        
        do{

       let manageObject = changevhicle
            manageObject.setValue(editmark, forKey: "mark")
            manageObject.setValue(editmodel, forKey: "model")
            manageObject.setValue(editimagename, forKey: "image")
            manageObject.setValue(editdate, forKey: "year")
            manageObject.setValue(id, forKey: "id")
            print(editimagename)
            saveImg(editimagename, imageView.image!)
            self.save()
         
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
  
        self.markTxt.isEnabled = false
        self.imageNameTxt.isEnabled = false
        self.modelTtx.isEnabled = false
        self.inuptTxt.isEnabled = false
        
        var vc = storyboard?.instantiateViewController(withIdentifier: "ViewController") as? ViewController
        vc?.vehicles = vehicles
        self.navigationController?.pushViewController(vc!, animated: true)
        
    }
    
    @IBAction func selectImage(_ sender: Any) {
        let imagecontroller = UIImagePickerController()
        imagecontroller.delegate  = self
        imagecontroller.sourceType = UIImagePickerController.SourceType.photoLibrary
        present(imagecontroller, animated: true, completion: nil)
        
        
    }
    
    //imagepicker
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        imageView.image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage
        self.dismiss(animated: true, completion: nil)
        
    }
    //datepicker
    func datePickerSetup() -> Void {
        datePicker = UIDatePicker()
        datePicker?.datePickerMode = .date
        datePicker?.addTarget(self, action:#selector( addViewController.dateChanged(datePicker: )), for:  .valueChanged)
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(addViewController.viewTapped(gestureRecogizer:)))
        
        
        inuptTxt.inputView = datePicker
    }
    @objc func viewTapped(gestureRecogizer: UITapGestureRecognizer) -> Void {
        view.endEditing(true)
    }
    
    
    @objc func dateChanged(datePicker:UIDatePicker){
        
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = "MM/dd/yyyy"
        inuptTxt.text = dateformatter.string(from: datePicker.date)
        view.endEditing(true)
    }
    //coredate
    func DataModelSetup(){
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {return }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Vehicle")
        
        do {
            vehicles = try managedContext.fetch(fetchRequest)
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
    }
    func getContext () -> NSManagedObjectContext {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        return appDelegate.persistentContainer.viewContext
    }
    
    func save() {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        appDelegate.saveContext()
        print("save finished")
    }
    func update() {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let managedContext = getContext()
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Vehicle")
        do{
            let result = try managedContext.fetch(fetchRequest)
            let objectUpdate = result[0] as! NSManagedObject
            
        }
        catch{
            print("update error")
        }
        
    }
    func changeVehicle(imgae:String, mark:String,model:String,year :String){
        let context = getContext()
        let vehicle1 = NSEntityDescription.insertNewObject(forEntityName: "Vehicle", into: context) as! Vehicle
        
        vehicle1.image=imgae
        vehicle1.id = Int32(id)
        vehicle1.mark=mark
        vehicle1.model=model
        vehicle1.year=year
        //vehicles.append(vehicle1)
        print("vehicle has been created")
        
    }
    func getVehicle(id: String) -> NSManagedObject?{
        let context = getContext()
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>.init(entityName: "Vehicle")
        fetchRequest.predicate = NSPredicate(format: "id = %@", id)
        do{
            let vs = try context.fetch(fetchRequest)
            let v = vs[0] as! NSManagedObject
            return v
        }
        catch {
            print("fetch error")
        }
        return nil
    }
}

