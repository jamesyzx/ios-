//
//  addViewController.swift
//  Assignment9
//
//  Created by James on 2018/11/27.
//  Copyright © 2018年 James. All rights reserved.
//

import UIKit
import CoreData
class addViewController: UIViewController,UINavigationControllerDelegate ,UIImagePickerControllerDelegate{

    @IBOutlet weak var modelLabel: UITextField!
    @IBOutlet weak var markLabel: UITextField!
    @IBOutlet weak var imageLabel: UITextField!
    @IBOutlet weak var inputTextField: UITextField!
    private var datePicker:UIDatePicker?
    @IBOutlet weak var imageview: UIImageView!
    @IBOutlet weak var selectBtn: UIButton!
    var vehicles: [NSManagedObject] = []
    var newid = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        datePickerSetup()
        DataModelSetup()
        

        // Do any additional setup after loading the view.
    }
    
    func DataModelSetup(){
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {return }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Vehicle")
        
        do {
            vehicles = try managedContext.fetch(fetchRequest)
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
    }
    func getContext () -> NSManagedObjectContext {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        return appDelegate.persistentContainer.viewContext
    }
    
    
    
    func save() {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        appDelegate.saveContext()
        print("save finished")
    }
    
    func update() {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let managedContext = getContext()
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Vehicle")
        do{
            let result = try managedContext.fetch(fetchRequest)
            let objectUpdate = result[0] as! NSManagedObject
            //            objectUpdate.setValue(department1)
        }
        catch{
            print("update error")
        }
        
    }
    func datePickerSetup() -> Void {
        datePicker = UIDatePicker()
        datePicker?.datePickerMode = .date
        datePicker?.addTarget(self, action:#selector( addViewController.dateChanged(datePicker: )), for:  .valueChanged)
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(addViewController.viewTapped(gestureRecogizer:)))
        
        
        inputTextField.inputView = datePicker
    }
    @objc func viewTapped(gestureRecogizer: UITapGestureRecognizer) -> Void {
        view.endEditing(true)
    }
    
    
    @objc func dateChanged(datePicker:UIDatePicker){

        let dateformatter = DateFormatter()
        dateformatter.dateFormat = "MM/dd/yyyy"
        inputTextField.text = dateformatter.string(from: datePicker.date)
        view.endEditing(true)
    }
    
    @IBAction func selectImage(_ sender: Any) {
        let imagecontroller = UIImagePickerController()
        imagecontroller.delegate  = self
        imagecontroller.sourceType = UIImagePickerController.SourceType.photoLibrary
        present(imagecontroller, animated: true, completion: nil)
        
        
        
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        imageview.image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage
        self.dismiss(animated: true, completion: nil)
        
    }
    @IBAction func saveBtn(_ sender: Any) {
       
        //validate
        let alert = UIAlertController(title: "Alert", message: "Please check your typing", preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        //if !markLabel.text!.isAlpha(ignoreDiacritics: true) { alert.show(); return}
      if !modelLabel.text!.isAlpha(ignoreDiacritics: true) { alert.show(); return}
        if !imageLabel.text!.isAlpha(ignoreDiacritics: true) { alert.show(); return}
        if inputTextField.text == "" { alert.show(); return}
        if imageview.image == nil { alert.show(); return}
     
        //save
        self.createVehicle(imgae: imageLabel.text!, mark: modelLabel.text!, model: markLabel.text!, year: inputTextField.text!)
        
        saveImg(imageLabel.text!, imageview.image!)
        self.save()
        
        
        var vc = storyboard?.instantiateViewController(withIdentifier: "ViewController") as? ViewController
        vc?.vehicles = vehicles
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    func createVehicle(imgae:String, mark:String,model:String,year :String){
        let context = getContext()
        let vehicle1 = NSEntityDescription.insertNewObject(forEntityName: "Vehicle", into: context) as! Vehicle
        vehicle1.image=imgae
        vehicle1.id = Int32(newid)
        vehicle1.mark=mark
        vehicle1.model=model
        vehicle1.year=year
        newid+=1
        vehicles.append(vehicle1)
        print("vehicle has been created")
        
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
public extension String{
    func isAlpha(ignoreDiacritics: Bool = false) -> Bool {
        if ignoreDiacritics {
            return self.range(of: "[^a-zA-Z]", options: .regularExpression) == nil && self != ""
        }
        else {
            return self.isAlpha()
        }
    }
    func isAlphaNum(ignoreDiacritics: Bool = false) -> Bool {
        if ignoreDiacritics {
            return self.range(of: "[^a-zA-Z0-9]", options: .regularExpression) == nil && self != ""
        }
        else {
            return self.isAlpha()
        }
    }
}

public extension UIAlertController {
    func show() {
        let win = UIWindow(frame: UIScreen.main.bounds)
        let vc = UIViewController()
        vc.view.backgroundColor = .clear
        win.rootViewController = vc
        win.windowLevel = UIWindow.Level.alert + 1
        win.makeKeyAndVisible()
        vc.present(self, animated: true, completion: nil)
    }
}
