//
//  Vehicle+CoreDataClass.swift
//  Assignment9
//
//  Created by James on 2018/11/25.
//  Copyright © 2018年 James. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Vehicle)
public class Vehicle: NSManagedObject {

}
