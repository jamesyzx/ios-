//
//  Department.swift
//  Assignment6UI
//
//  Created by James on 2018/10/27.
//  Copyright © 2018年 James. All rights reserved.
//

import Foundation
class Department{
    var name : String?
    var phone : String?
    var vehiclelist : [Vehicle]?
    var employeelist : [Employee]?
 
}
