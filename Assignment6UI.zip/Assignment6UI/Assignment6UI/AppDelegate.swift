//
//  AppDelegate.swift
//  Assignment6UI
//
//  Created by James on 2018/10/27.
//  Copyright © 2018年 James. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate, UITextFieldDelegate, UITextViewDelegate {

    var window: UIWindow?
    var view = UIView()
    var textField1 = UITextField()
    var textField2 = UITextField()
    var textField3 = UITextField()
    var textField4 = UITextField()
    var textField5 = UITextField()
    var textField6 = UITextField()
    var textField7 = UITextField()
    var textField8 = UITextField()
    var addbtn = UIButton()
    var listbtn = UIButton()
    var searchbtn = UIButton()
     var backbtn = UIButton()
    var addTextView = UITextView()
    var searchTxtField = UITextField()
    var dealer = Dealer()
    var department = Department()
    var carlist = [Vehicle]()
    
 
    
    func createbtn(_ num: Int)->UIButton{
        
        let btn:UIButton = UIButton(type:.system)
        switch num {
        case 0: btn.setTitle("Add", for:.normal )
        btn.frame=CGRect(x:110,y:200,width: 200, height: 60)
        btn.setTitleColor(UIColor.black, for: .normal)
        btn.backgroundColor=UIColor.gray
        btn.addTarget(self, action: #selector(addaction), for: .touchUpInside)
        case 1: btn.setTitle("List", for:.normal )
        btn.frame=CGRect(x:110,y:400,width: 200, height: 60)
        btn.setTitleColor(UIColor.black, for: .normal)
        btn.backgroundColor=UIColor.gray
        btn.addTarget(self, action: #selector(listaction), for: .touchUpInside)
        case 2: btn.setTitle("Search", for:.normal )
        btn.frame=CGRect(x:110,y:600,width: 200, height: 60)
        btn.setTitleColor(UIColor.black, for: .normal)
        btn.backgroundColor=UIColor.gray
        btn.addTarget(self, action: #selector(searchaction), for: .touchUpInside)
        case 3: btn.setTitle("Back", for: .normal)
        btn.frame=CGRect(x:110,y:700,width: 200, height: 60)
        btn.setTitleColor(UIColor.black, for: .normal)
        btn.backgroundColor=UIColor.gray
        btn.addTarget(self, action: #selector(backaction), for: .touchUpInside)
        btn.tag = 2
        case 4: btn.setTitle("Back", for: .normal)
        btn.frame=CGRect(x:110,y:700,width: 200, height: 60)
        btn.setTitleColor(UIColor.black, for: .normal)
        btn.backgroundColor=UIColor.gray
        btn.addTarget(self, action: #selector(backaction), for: .touchUpInside)
        btn.tag = 22
        default:
            print("btn wrong")
        }
        
        
        return btn
    }
    func createTextField(_ num: Int) -> UITextField {
        
        let textField = UITextField(frame: CGRect(x:100.0, y:Double(130+(num)*50), width:200.0, height:30.0))
        textField.textAlignment = NSTextAlignment.center
        textField.textColor = UIColor.blue
        textField.backgroundColor = UIColor.white
        textField.borderStyle = .line
        textField.autocapitalizationType = UITextAutocapitalizationType.words
        textField.clearButtonMode = .whileEditing
        switch num{
        case 1: textField.placeholder = "Enter Make(String)"
        case 2: textField.placeholder = "Enter Miles(Double)"
        case 3: textField.placeholder = "Enter Model(String)"
        case 4: textField.placeholder = "Enter Photo(String)"
        case 5: textField.placeholder = "Enter Price(Double)"
        case 6: textField.placeholder = "Enter Rating(Int)"
        case 7: textField.placeholder = "Enter Type(String)"
        case 8: textField.placeholder = "Enter Year(YYYY)"
        default:
            print("")
        }
        
        textField.keyboardType = .default
        textField.returnKeyType = .done
        textField.delegate = self
        
        return textField
    }
  
    @objc func addaction(sender: UIButton!){
        let addView = UITextView(frame: CGRect(x:0,y:0,width:400, height:800))
        addView.tag = 5
        addView.delegate = self
        view.addSubview(addView)
        
        addTextView = UITextView(frame: CGRect(x:0,y:0,width:400, height:800))
        addTextView.tag = 1
        addTextView.delegate = self
        view.addSubview(addTextView)
        
        textField1 = createTextField(1)
         textField1.delegate = self
        textField1.tag = 6
        view.addSubview( textField1)
        textField2 = createTextField(2)
        textField2.delegate = self
        textField2.tag = 7
        view.addSubview( textField2)
        textField3 = createTextField(3)
        textField3.delegate = self
       textField3.tag = 8
        view.addSubview( textField3)
        textField4 = createTextField(4)
        textField4.delegate = self
      textField4.tag = 9
        view.addSubview( textField4)
        textField5 = createTextField(5)
        textField5.delegate = self
      textField5.tag = 10
        view.addSubview( textField5)
        textField6 = createTextField(6)
        textField6.delegate = self
        textField6.tag = 11
        view.addSubview( textField6)
        textField7 = createTextField(7)
        textField7.delegate = self
       textField7.tag = 12
        view.addSubview( textField7)
        textField8 = createTextField(8)
        textField8.delegate = self
       textField8.tag = 13
        view.addSubview( textField8)
        
        let addbtn:UIButton = UIButton(frame: CGRect(x:90, y: 620, width: 250, height: 40))
        addbtn.setTitle("Add a Vehicle", for: .normal)
        addbtn.addTarget(self, action:#selector(addcaraction), for: .touchUpInside)
        addbtn.tag = 4
        addbtn.layer.cornerRadius = 20.0
        addbtn.layer.borderColor = UIColor.gray.cgColor
        addbtn.layer.borderWidth = 2.0
        addbtn.backgroundColor = UIColor.gray
        view.addSubview(addbtn)
        backbtn =  createbtn(3)
        view.addSubview(backbtn)
    }
    func checkDate(s:String)-> Bool{
        
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = "YYYY-MM-dd"
        if  let newDate = dateformatter.date(from: s)
        {
            return true
        }
        else{
            return false
        }
        
    }
    func searchcarbytype(a:String)->[Vehicle]{
        var getcarlist = [Vehicle]()
        for i  in department.vehiclelist!
        {
        
            let a = (i.type).range(of: a)
            
            if a != nil
            {
                getcarlist.append(i)
            }
        }
        return getcarlist
}

    @objc func addcaraction(sender: UIButton!){
        let alert = UIAlertController(title: "Alert", message: "Please enter correct!", preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        //verify textFields
        if !textField1.text!.isAlpha(ignoreDiacritics: true) {  alert.show(); print("1 wrong"); return}
        if !textField3.text!.isAlpha(ignoreDiacritics: true) { alert.show(); print("3 wrong"); return}
        if !textField4.text!.isAlpha(ignoreDiacritics: true) { alert.show(); print("4 wrong"); return}
        if !textField7.text!.isAlpha(ignoreDiacritics: true) {alert.show(); print("7 wrong"); return}
        guard checkDate(s:textField8.text! ) == true else{alert.show();print("year wrong");return}
        guard let d2 = Double(textField2.text!) else{alert.show();print("mile wrong"); return}
        guard let d5 = Double(textField5.text!) else{alert.show();  print("d5 wrong");return}
        guard let i6 = Int(textField6.text!)else{alert.show();print("i6 wrong");return}
        
        print("success")
        let vehicle = Vehicle(make: textField1.text!, miles: d2, model: textField3.text!, photo: textField4.text!, price: d5, rating: i6, type: textField7.text!, year: textField8.text!)
        carlist.append(vehicle)
        department.vehiclelist=carlist
        let alert1 = UIAlertController(title: "Success", message: "Add success", preferredStyle: UIAlertController.Style.alert)
        alert1.show()
        alert1.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        textField1.text?.removeAll()
        textField2.text?.removeAll()
        textField3.text?.removeAll()
        textField4.text?.removeAll()
        textField5.text?.removeAll()
        textField6.text?.removeAll()
        textField7.text?.removeAll()
        textField8.text?.removeAll()
        
    }
    @objc func listaction(sender: UIButton!){
        let blankView = UITextView(frame: CGRect(x:0,y:0,width:400, height:800))
        blankView.backgroundColor = UIColor.white
        blankView.tag = 19
        blankView.delegate = self
        view.addSubview(blankView)
        
        let listView = UITextView(frame: CGRect(x:0,y:300,width:400, height:800))
        listView.backgroundColor = UIColor.white
        listView.isScrollEnabled = false
        listView.tag = 15
        listView.delegate = self
        listView.textAlignment = .center
        listView.font = UIFont.boldSystemFont(ofSize: 20)
        if department.vehiclelist == nil
        {
            let str = "No record!"
            
            listView.text.append(str)
        }
        else{
            for i in department.vehiclelist!
            {
                let str = "make:\(i.make),miles:\(i.miles),model:\(i.model),price:\(i.price),rating:\(i.rating),photo:\(i.photo)type:\(i.type),year:\(i.year) "
                listView.text.append(str)
            }
        }
       
        
        view.addSubview(listView)
        
        
        
        backbtn =  createbtn(4)
        view.addSubview(backbtn)
    }
    @objc func searchaction(sender: UIButton!){
        
        let searchView = UITextView(frame: CGRect(x:0,y:0,width:400, height:800))
        searchView.tag = 16
        searchView.delegate = self
        view.addSubview(searchView)
        searchTxtField = UITextField(frame: CGRect(x:100.0, y:Double(130+(4)*50), width:200.0, height:30.0))
        searchTxtField.placeholder = "Type"
        searchTxtField.borderStyle = .line
        searchTxtField.delegate = self
        searchTxtField.tag = 18
        view.addSubview(searchTxtField)
        
        
        let searchcarbtn:UIButton = UIButton(frame: CGRect(x:90, y: 620, width: 250, height: 40))
        searchcarbtn.setTitle("Search Vehicles", for: .normal)
        searchcarbtn.addTarget(self, action:#selector(searchcaraction), for: .touchUpInside)
        searchcarbtn.tag = 17
        searchcarbtn.layer.cornerRadius = 20.0
        searchcarbtn.layer.borderColor = UIColor.gray.cgColor
        searchcarbtn.layer.borderWidth = 2.0
        searchcarbtn.backgroundColor = UIColor.gray
        view.addSubview(searchcarbtn)
        backbtn =  createbtn(3)
        view.addSubview(backbtn)
    }
     @objc func searchcaraction(sender: UIButton!){
        let blankView = UITextView(frame: CGRect(x:0,y:0,width:400, height:800))
        blankView.backgroundColor = UIColor.white
        blankView.tag = 21
        blankView.delegate = self
        view.addSubview(blankView)
        
        let showview = UITextView(frame: CGRect(x:0,y:300,width:400, height:800))
        showview.tag = 20
        showview.delegate = self
        showview.textAlignment = .center
        showview.font = UIFont.boldSystemFont(ofSize: 20)
       
        if  searchTxtField == nil || department.vehiclelist == nil
        {
            
            let str = "No record!"
            showview.text.append(str)
        }
        else{
            for i in searchcarbytype(a: searchTxtField.text!)
            {
                let str = "make:\(i.make),miles:\(i.miles),model:\(i.model),price:\(i.price),rating:\(i.rating),photo:\(i.photo)type:\(i.type),year:\(i.year)"
                showview.text.append(str)
            }
            
         
        }
      
        view.addSubview(showview)
        backbtn = createbtn(4)
        view.addSubview(backbtn)
        
    }
    @objc func backaction(sender: UIButton!){
        
        for n in 1...100{
            if let viewWithTag = view.viewWithTag(n){
                viewWithTag.removeFromSuperview()
            }
        }
    }

// first page will show at here
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        window = UIWindow(frame: UIScreen.main.bounds)
        if let window = window {
            window.backgroundColor = UIColor.white
            window.rootViewController = UIViewController()
            window.makeKeyAndVisible()
        }
        
        let viewRect: CGRect = CGRect(x:0,y:20,width:420, height:1000);
        
        view = UIView(frame:viewRect)
        window?.addSubview(view); // window is coming soon
        let label1 = UILabel(frame: CGRect(x: 20, y: 50, width: 380, height: 100))
        label1.backgroundColor = UIColor.orange
        label1.textAlignment = .center
        label1.adjustsFontSizeToFitWidth = true
        label1.font = UIFont.boldSystemFont(ofSize: 24)
        label1.textColor = UIColor.black
        label1.text = "Welcome"
        self.view.addSubview(label1)
        addbtn = createbtn(0)
        listbtn = createbtn(1)
        searchbtn = createbtn(2)
        self.view.addSubview(addbtn)
        self.view.addSubview(listbtn)
        self.view.addSubview(searchbtn)
        return true
    }

    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
        
        
        
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    
        
    
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
        
    
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
        
        
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    
        
    }
    
 

}
extension String{
    func isAlpha(ignoreDiacritics: Bool = false) -> Bool {
        if ignoreDiacritics {
            return self.range(of: "[^a-zA-Z]", options: .regularExpression) == nil && self != ""
        }
        else {
            return self.isAlpha()
        }
    }
    func isAlphaNum(ignoreDiacritics: Bool = false) -> Bool {
        if ignoreDiacritics {
            return self.range(of: "[^a-zA-Z0-9]", options: .regularExpression) == nil && self != ""
        }
        else {
            return self.isAlpha()
        }
    }
}

public extension UIAlertController {
    func show() {
        let win = UIWindow(frame: UIScreen.main.bounds)
        let vc = UIViewController()
        vc.view.backgroundColor = .clear
        win.rootViewController = vc
        win.windowLevel = UIWindow.Level.alert + 1
        win.makeKeyAndVisible()
        vc.present(self, animated: true, completion: nil)
    }
}
