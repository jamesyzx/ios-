//
//  Dealer.swift
//  Assignment6UI
//
//  Created by James on 2018/10/27.
//  Copyright © 2018年 James. All rights reserved.
//

import Foundation

class Dealer{
    var address : String?
    var city : String?
    var name : String?
    var phone : String?
    var zip : String?
    var departmentlist : [Department]?

}
