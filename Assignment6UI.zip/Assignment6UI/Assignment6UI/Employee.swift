//
//  Employee.swift
//  Assignment6UI
//
//  Created by James on 2018/10/27.
//  Copyright © 2018年 James. All rights reserved.
//

import Foundation
class Employee{
    var address : String?
    var city : String?
    var firstname : String?
    var lastname : String?
    var phone : String?
    var ssn : String?
    var zip : String?
 
}
