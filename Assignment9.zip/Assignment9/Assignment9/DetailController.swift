//
//  DetailController.swift
//  Assignment9
//
//  Created by James on 2018/11/13.
//  Copyright © 2018年 James. All rights reserved.
//

import UIKit

class DetailController: UIViewController {

    
    @IBOutlet weak var markLabel: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var modelLabel: UILabel!
    @IBOutlet weak var yearLabel: UILabel!
    
    var img = UIImage()
    var mark = ""
    var model = ""
    var year = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        markLabel.text = mark
        modelLabel.text = model
        yearLabel.text = year
        imageView.image = img

        // Do any additional setup after loading the view.
    }
    

    

}
