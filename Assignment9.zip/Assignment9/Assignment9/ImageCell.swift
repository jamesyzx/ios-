//
//  ImageCell.swift
//  Assignment9
//
//  Created by James on 2018/11/13.
//  Copyright © 2018年 James. All rights reserved.
//

import UIKit

class ImageCell: UITableViewCell {

    @IBOutlet weak var carImageView: UIImageView!
    @IBOutlet weak var carTtileLabel: UILabel!

    func setImage(image :Image)->Void{
        
         carImageView.image = image.image
        
        carTtileLabel.text = image.title
       
    }
    
}
