//
//  ViewController.swift
//  Assignment9
//
//  Created by James on 2018/11/13.
//  Copyright © 2018年 James. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var cars :[Image] = []
    
    @IBOutlet weak var addBtn: UIBarButtonItem!
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        cars = createArray()
//        tableView.delegate = self
//        tableView.dataSource = self
        
    }
    
    
    
    
    
    @IBAction func addaction(_ sender: Any) {
        let alert = UIAlertController(title: "Add Car", message: nil, preferredStyle: .alert)
        alert.addTextField{(desstf) in desstf.placeholder = "Enter Car Picture"
        }
        alert.addTextField{(mark) in mark.placeholder = "Enter Car Mark"
        }
        alert.addTextField{(model) in model.placeholder = "Enter Car Model"
        }
        alert.addTextField{(year) in year.placeholder = "Enter Car Year"
        }
        let action1 = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
//        let action3 = UIAlertAction(title: "Remove", style: .destructive){(_)in
//
//            alert.textFields?.first?.text?.removeAll()
//            alert.textFields![1].text?.removeAll()
//            alert.textFields![2].text?.removeAll()
//            alert.textFields![3].text?.removeAll()
//
//        }
        let action2 = UIAlertAction(title: "Add", style: .default){
            (_)in
            guard let car = alert.textFields?.first?.text
                else{return}
            //            if !self.checkpicture(s: car)
            //            {print("car")
            //                return}
            guard let m = alert.textFields![1].text
                else{return}
            //            if !m.isAlpha(ignoreDiacritics: true)
            //            {print("mark")
            //                return }
            guard let mo = alert.textFields![2].text
                else{return}
            //            if !mo.isAlpha(ignoreDiacritics: true)
            //            {print("model")
            //            return }
            guard let y = alert.textFields![3].text
                else{return}
            //           if !self.checkDate(s: y)
            //           {print("year")
            //        return}
            let newImage = UIImage(named: car)
            let imageView = UIImageView(image:newImage)
            let image1 = Image(image: newImage!, title: m, year:y,model:mo)
            self.cars.append(image1)
            self.tableView.reloadData()
        }
        
       alert.addAction(action1)
        alert.addAction(action2)
       // alert.addAction(action3)
        present(alert, animated: true, completion: nil)
        
        
        
//        let alertController = UIAlertController(title: "保存成功!",
//                                                message: nil, preferredStyle: .alert)
//        //显示提示框
//        self.present(alertController, animated: true, completion: nil)
//        //两秒钟后自动消失
//        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 2) {
//            self.presentedViewController?.dismiss(animated: false, completion: nil)
//        }
    }
    func createArray()->[Image]{
        var temImages :[Image] = []
        let newImage = UIImage(named: "1")
        let imageView = UIImageView(image:newImage)
        let image1 = Image(image: newImage!, title: "BMW",year:"1998",model:"M3")
        temImages.append(image1)
        let newImage1 = UIImage(named: "2")
        let imageView1 = UIImageView(image:newImage1)
        let image11 = Image(image: newImage1!, title: "BENZ",year:"1999",model:"SLS")
        temImages.append(image11)
        return temImages
    }
    

    @IBAction func editaction(_ sender: UIBarButtonItem) {
         self.tableView.isEditing = !self.tableView.isEditing
        sender.title = (self.tableView.isEditing) ?"Done":"Edit"
    }
    
}
extension ViewController:UITableViewDataSource,UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cars.count
    }
    
    //设置section的数量
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    //设置tableview的cell
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let image = cars[indexPath.row]
        
        let  cell = tableView.dequeueReusableCell(withIdentifier: "ImageCell") as! ImageCell
        
        print("dwqdwq\(image.image)")
        cell.setImage(image: image)
        
        return cell
        
        
    }
   
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        guard editingStyle == .delete else {
            return
        }
        cars.remove(at: indexPath.row)
        tableView.deleteRows(at: [indexPath], with: .right)
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        var dc = storyboard?.instantiateViewController(withIdentifier: "DetailController") as? DetailController
        dc?.mark = cars[indexPath.row].title
        dc?.img = cars[indexPath.row].image
        dc?.model  = cars[indexPath.row].model
        dc?.year = cars[indexPath.row].year
        
        self.navigationController?.pushViewController(dc!, animated: true)
    }
    
    
    func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        
       let carTemp = cars[sourceIndexPath.row]
        cars.remove(at: sourceIndexPath.row)
        cars.insert(carTemp, at: sourceIndexPath.row)
        
        
    }
    
    

}

